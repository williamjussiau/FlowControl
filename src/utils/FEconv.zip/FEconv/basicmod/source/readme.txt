Basic scheme of dependencies on basicmod modules:

    compiler -> os -> report -> convers, alloc 
                                   |          \
                                   v           > system
                                 files -------/
    
